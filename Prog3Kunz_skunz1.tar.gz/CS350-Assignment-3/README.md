# CS350 Assignment 3

Sean Kunz and Brian Grant

./pageRep to run

To make the graphs, type make test
