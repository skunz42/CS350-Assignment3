# CS350 Assignment 3

Sean Kunz and Brian Grant

Type make to compile, and then type make test, which will make the csv files and the graphs
